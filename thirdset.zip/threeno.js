let a=10;
let b=6;
let c=15;
if(a>b&& a>c)
{
  console.log("a is greater");
}
else if(b>a&& b>c)
{
  console.log("b is greater");
}
else 
{
  console.log("c is greater");
}