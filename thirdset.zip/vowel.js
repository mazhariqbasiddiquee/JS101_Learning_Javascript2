let char ="a"
if(char=="a"||char=="e"||char=="i"||char=="o"||char=="u")
{
  console.log("Vowel");
}
else
{
  console.log("consonant");
}
