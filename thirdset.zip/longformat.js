let days="Sun";
switch(days)
  {
      case "Sun":console.log("Sunday");
      break;
      case "Mon":console.log("Monday");
      break;
      case "Tue" :console.log("Tuesday");
      break;
      case "Wed" :console.log("Wednesday");
      break;
      case "Thu" :console.log("Thursday");
      break;
      case "Fri" :console.log("Friday");
      break;
      case "Sat" :console.log("Saturday");
      break;
      
      
      
      
      
  }